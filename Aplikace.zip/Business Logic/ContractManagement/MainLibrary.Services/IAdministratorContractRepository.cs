﻿using MainLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MainLibrary.Services
{
    public interface IAdministratorContractRepository
    {
        IEnumerable<AdministratorContract> GetAdministratorContracts();
    }
}
