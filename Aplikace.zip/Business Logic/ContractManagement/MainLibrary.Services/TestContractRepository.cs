﻿using MainLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MainLibrary.Services
{
    public class TestContractRepository : IContractRepository
    {
        private List<Contract> _contracts;
        public TestContractRepository()
        {
            _contracts = new List<Contract>()
            {
                new Contract() { RegistrationNumbre = 1, Institution = "ČSOB",
                    Client = new Person(){ FirstName = "Petr", LastName = "Mladý", Email = "mlady@sez.cz", PhoneNumber = "731123", IdentificationNumbre = "990526", Age = 21},
                    DateCloseContract = new DateTime(2020, 5, 12), DateValidContract = new DateTime(2020, 5, 20), DateEndContract = new DateTime(2020, 6, 12)
                },
                new Contract() { RegistrationNumbre = 1, Institution = "ČSOB",
                    Client = new Person(){ FirstName = "Petr", LastName = "Mladý", Email = "mlady@sez.cz", PhoneNumber = "731123", IdentificationNumbre = "990526", Age = 21},
                    DateCloseContract = new DateTime(2020, 5, 12), DateValidContract = new DateTime(2020, 5, 20), DateEndContract = new DateTime(2020, 6, 12)
                }
            };
        }
        public IEnumerable<Contract> GetContracts()
        {
            return _contracts;
        }

    }
}
