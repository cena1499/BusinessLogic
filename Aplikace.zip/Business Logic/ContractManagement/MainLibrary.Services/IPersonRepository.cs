﻿using MainLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MainLibrary.Services
{
    public interface IPersonRepository
    {
        IEnumerable<Person> GetPeople();
    }
}
