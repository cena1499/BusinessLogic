﻿using MainLibrary.Models;
using System;
using System.Collections.Generic;

namespace MainLibrary.Services
{
    public interface IContractRepository
    {
        IEnumerable<Contract> GetContracts();
    }
}
