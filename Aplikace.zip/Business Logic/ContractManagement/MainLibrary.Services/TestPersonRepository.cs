﻿using MainLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MainLibrary.Services
{
    public class TestPersonRepository : IPersonRepository
    {
        private List<Person> _people;
        public TestPersonRepository()
        {
            _people = new List<Person>()
            {
                new Person(){ FirstName = "Zdeněk", LastName = "Karlík", Email = "kar@seznam.cz", PhoneNumber = "123456", IdentificationNumbre = "980516", Age = 22},
                new Person(){ FirstName = "Zdeněk", LastName = "Karlík", Email = "kar@seznam.cz", PhoneNumber = "123456", IdentificationNumbre = "980516", Age = 22},
                new Person(){ FirstName = "Zdeněk", LastName = "Karlík", Email = "kar@seznam.cz", PhoneNumber = "123456", IdentificationNumbre = "980516", Age = 22}
            };
        }

        public IEnumerable<Person> GetPeople()
        {
            return _people;
        }
    }
}
