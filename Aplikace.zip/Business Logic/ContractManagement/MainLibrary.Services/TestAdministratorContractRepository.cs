﻿using MainLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MainLibrary.Services
{
    public class TestAdministratorContractRepository : IAdministratorContractRepository
    {
        private List<AdministratorContract> _administratorContracts;
        private List<Contract> contracts1 = new List<Contract>()
        {
            new Contract() { RegistrationNumbre = 1, Institution = "ČSOB",
                    Client = new Person(){ FirstName = "Petr", LastName = "Mladý", Email = "mlady@sez.cz", PhoneNumber = "731123", IdentificationNumbre = "990526", Age = 21},
                    DateCloseContract = new DateTime(2020, 5, 12), DateValidContract = new DateTime(2020, 5, 20), DateEndContract = new DateTime(2020, 6, 12)
                },
            new Contract() { RegistrationNumbre = 2, Institution = "ČSOB",
                Client = new Person(){ FirstName = "Petr", LastName = "Mladý", Email = "mlady@sez.cz", PhoneNumber = "731123", IdentificationNumbre = "990526", Age = 21},
                DateCloseContract = new DateTime(2020, 5, 12), DateValidContract = new DateTime(2020, 5, 20), DateEndContract = new DateTime(2020, 6, 12)
            }
        };

        private List<Contract> contracts2 = new List<Contract>()
        {
            new Contract() { RegistrationNumbre = 3, Institution = "ČSOB",
                Client = new Person(){ FirstName = "Petr", LastName = "Mladý", Email = "mlady@sez.cz", PhoneNumber = "731123", IdentificationNumbre = "990526", Age = 21},
                DateCloseContract = new DateTime(2020, 5, 12), DateValidContract = new DateTime(2020, 5, 20), DateEndContract = new DateTime(2020, 6, 12)
            }
        };

        public TestAdministratorContractRepository()
        {
            _administratorContracts = new List<AdministratorContract>()
            {
                new AdministratorContract() { FirstName = "Zdeněk", LastName = "Karlík", Email = "kar@seznam.cz", PhoneNumber = "123456", IdentificationNumbre = "980516", Age = 22, Contracts = contracts1},
                new AdministratorContract() { FirstName = "Pavel", LastName = "Kol", Email = "kar@sez.cz", PhoneNumber = "1234", IdentificationNumbre = "9805", Age = 28, Contracts = contracts2}
            };
        }

        public IEnumerable<AdministratorContract> GetAdministratorContracts()
        {
            return _administratorContracts;
        }
    }
}
