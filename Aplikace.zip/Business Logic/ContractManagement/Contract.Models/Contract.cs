﻿using System;

namespace Contract.Models
{
    public class Class1
    {
    }
}
