﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MainLibrary.Models;
using MainLibrary.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ContractManagement.Pages.Contracts
{
    public class IndexModel : PageModel
    {
        private readonly IAdministratorContractRepository administratorContractRepository;
        public IEnumerable<AdministratorContract> AdministratorContracts { get; set; }
        public IndexModel(IAdministratorContractRepository administratorContractRepository)
        {
            this.administratorContractRepository = administratorContractRepository;
        }
        public void OnGet()
        {
            AdministratorContracts = administratorContractRepository.GetAdministratorContracts();
        }
    }
}