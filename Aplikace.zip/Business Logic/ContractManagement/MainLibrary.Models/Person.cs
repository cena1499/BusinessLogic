﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MainLibrary.Models
{
    public class Person
    {
        public string FirstName { get; set; } //Křestní jméno
        public string LastName { get; set; } //Příjmení
        public string Email { get; set; } // Email
        public string PhoneNumber { get; set; } //Telefonní číslo
        public string IdentificationNumbre { get; set; } //Rodné číslo
        public int Age { get; set; } //Věk
    }
}
