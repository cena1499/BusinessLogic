﻿using System;

namespace MainLibrary.Models
{
    public class Contract
    {
        public int RegistrationNumbre { get; set; } //Evidenční číslo
        public string Institution { get; set; } //Název instituce
        public Person Client { get; set; } //Jméno klienta
        public AdministratorContract AdminContract { get; set; } //Správce smlouvy
        public DateTime DateCloseContract { get; set; } //Datum uzavření smlouvy
        public DateTime DateValidContract { get; set; } //Datum platnosti smlouvy
        public DateTime DateEndContract { get; set; } //Datum ukončení smlouvy

    }
}
