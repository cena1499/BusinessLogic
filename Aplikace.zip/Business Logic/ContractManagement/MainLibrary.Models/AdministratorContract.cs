﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MainLibrary.Models
{
    public class AdministratorContract : Person
    {
        public List<Contract> Contracts { get; set; } //Seznam smluv

    }
}
